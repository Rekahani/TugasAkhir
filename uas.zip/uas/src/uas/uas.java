/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Hp
 */

public class uas extends JFrame implements ActionListener {

    /**
     * Creates new form uas
     */
    
    public uas() throws SQLException {
        
        JFrame f=new JFrame("FORM PENILAIAN MAHASISWA");
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        setSize (550, 460);
        setLayout(null);
        
        
        judul = new JLabel ("NILAI AKHIR MAHASISWA"); judul.setBounds(200, 26, 200, 25);
        tnama = new JTextField(); tnama.setBounds(100, 70, 170, 25);
        lnama = new JLabel ("Nama   "); lnama.setBounds(20, 70, 90, 25);
        lnim = new JLabel ("NIM "); lnim.setBounds(20, 110, 90, 25);
        tnim = new JTextField(); tnim.setBounds(100, 110, 170, 25);
        lnilaiTugas = new JLabel ("Nilai Tugas   "); lnilaiTugas.setBounds(20, 150, 90, 25);
        tnilaiTugas = new JTextField(); tnilaiTugas.setBounds(100, 150, 170, 25);
        lnilaiKuis = new JLabel ("Nilai Kuis    "); lnilaiKuis.setBounds(20, 190, 90, 25);
        tnilaiKuis = new JTextField(); tnilaiKuis.setBounds(100, 190, 170, 25);
        lnilaiUts = new JLabel ("Nilai UTS     "); lnilaiUts.setBounds(20, 230, 90, 25);
        tnilaiUts = new JTextField(); tnilaiUts.setBounds(100, 230, 170, 25);
        lnilaiUas = new JLabel ("Nilai UAS     "); lnilaiUas.setBounds(20, 270, 90, 25);
        tnilaiUas = new JTextField(); tnilaiUas.setBounds(100, 270, 170, 25);
        
        ltotal = new JLabel ("Nilai Total   "); ltotal.setBounds(320, 70, 90, 25);
        ttotal = new JTextField(); ttotal.setBounds(400, 70, 100, 25);
        lratarata = new JLabel ("Rata - Rata    "); lratarata.setBounds(320, 110, 90, 25);
        tratarata = new JTextField(); tratarata.setBounds(400, 110, 100, 25);
        lgrade = new JLabel ("Grade "); lgrade.setBounds(320, 150, 90, 25);
        tgrade = new JTextField(); tgrade.setBounds(400, 150, 100, 25);
        
        tombolHitung = new JButton("Hitung");
        tombolHitung.setBounds(20, 320, 80, 25);
        tombolReset = new JButton("Reset");
        tombolReset.setBounds(110, 320, 70, 25);
        tombolSimpan = new JButton("Simpan");
        tombolSimpan.setBounds(190, 320, 80, 25);
        lihatData = new JButton("Lihat data");
        lihatData.setBounds(320, 320, 180, 25);
        
        
        add(lnama);add(lnim);add(lnilaiTugas);add(lnilaiKuis);add(lnilaiUts);add(lnilaiUas);
        add(ltotal);add(lratarata);add(lgrade);
        add(tnama);add(tnim);add(tnilaiTugas);add(tnilaiKuis);add(tnilaiUts);add(tnilaiUas);
        add(ttotal);add(tratarata);add(tgrade);
        add(tombolHitung);add(tombolReset);add(tombolSimpan);add(lihatData);
        add(judul);
        
        tombolHitung.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                double b1, b2, b3, b4, hasil, ratarata;
                String grade;
                
                b1=Double.parseDouble(tnilaiTugas.getText());
                b2=Double.parseDouble(tnilaiKuis.getText());
                b3=Double.parseDouble(tnilaiUts.getText());
                b4=Double.parseDouble(tnilaiUas.getText());
                hasil=((b1 * 15/100) + (b2 * 20/100) + (b3 * 30/100) + (b4 * 35/100));
                ttotal.setText(Double.toString(hasil));
                
                ratarata = ((b1 + b2 + b3 + b4)/4);
                tratarata.setText(Double.toString(ratarata));
                
                
                grade = tgrade.getText();
                if (hasil >= 89.0 && hasil <= 100 ) {
                    grade = "A";
                    tgrade.setText(tgrade.getText() +grade);
                }
                else if (hasil >= 79.0 && hasil <= 88.9){
                    grade = "B";
                    tgrade.setText(tgrade.getText() +grade);
                }
                else if (hasil >= 69.0 && hasil <= 78.9){
                    grade = "C";
                    tgrade.setText(tgrade.getText() +grade);
                }
                else if (hasil >= 59.0 && hasil <= 68.9){
                    grade = "D";
                    tgrade.setText(tgrade.getText() +grade);
                }
                else if (hasil <= 48.0){
                    grade = "E";
                    tgrade.setText(tgrade.getText() +grade);
                }  
            }

        });
        
        tombolReset.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                tnama.setText("");
                tnim.setText("");
                tnilaiTugas.setText("");
                tnilaiKuis.setText("");
                tnilaiUts.setText("");
                tnilaiUas.setText("");
               
                tratarata.setText("");
                ttotal.setText("");
                tgrade.setText("");
                tnama.requestFocus();
            }
        });
        
        lihatData.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                datanilai a;
                a=new datanilai();
                a.setVisible(true);
                
            }
        });
        
        
        tombolSimpan.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection conn = (Connection)
                    DriverManager.getConnection("jdbc:mysql://localhost:3306/db_mahasiswa","root", "");
                    conn.createStatement().executeUpdate("insert into mahasiswa values" + "('"+tnim.getText()+"', '"+tnama.getText()+"', '"+tnilaiTugas.getText()+"', '"+tnilaiKuis.getText()+"', '"+tnilaiUts.getText()+"', '"+tnilaiUas.getText()+"', '"+ttotal.getText()+"', '"+tratarata.getText()+"', '"+tgrade.getText()+"')");
                    JOptionPane.showMessageDialog(null, "Data Tersimpan !");
                tombolReset();
                }catch(SQLException ex) {
                    Logger.getLogger(uas.class.getName()).log(Level.SEVERE, null, ex);
                    
                }
            }

            private void tombolReset() {
                tnama.setText("");
                tnim.setText("");
                tnilaiTugas.setText("");
                tnilaiKuis.setText("");
                tnilaiUts.setText("");
                tnilaiUas.setText("");
               
                tratarata.setText("");
                ttotal.setText("");
                tgrade.setText("");
                tnama.requestFocus(); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        
//        setVisible(true);
//        initComponents();

    } 
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImages(getIconImages());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 404, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 309, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws SQLException {
//        new uas();
//        new uas().setVisible(true);
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(uas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(uas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(uas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(uas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    //                new uas().setVisible(true);
                    new uas().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(uas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    //http://www.java-sc.com/2015/07/menghitung-nilai-dengan-java-gui.html

    

    
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Connection conn;
    public ResultSet rs;
    public PreparedStatement pst;
    private JFrame frame;
    private JLabel judul, lnama, lnim, lnilaiTugas, lnilaiKuis, lnilaiUts, lnilaiUas;
    private JLabel lnama2, lnim2, ltotal, lratarata, lgrade;
    private JTextField tnama, tnim, tnilaiTugas, tnilaiKuis, tnilaiUts, tnilaiUas;
    private JTextField ttotal, tratarata, tgrade;
    private JButton tombolHitung, tombolReset, tombolSimpan, lihatData;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
